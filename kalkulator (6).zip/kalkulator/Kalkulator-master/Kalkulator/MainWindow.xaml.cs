﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kalkulator
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double equal;
        bool operandPressed;
        string action;
        List<string> operands;
        double f = 0;
        public MainWindow()
        {
            InitializeComponent();
            equal = .0;
            operandPressed = false;
            action = "";
            //double Pi = 3.14;
            operands = new List<string>();
            string[] tmp = { "+", "-", "×", "÷", "=", "x²", "%", "(", ")", "e", "log", "mod", "exp", "✓", "π" };
            
            operands.AddRange(tmp.ToList());
        }

        private void btnnumber_Click(object sender, RoutedEventArgs e)
        {
            var data = ((Button)sender).Content.ToString();
            if (operandPressed && !operands.Contains(data))
            {
                f = Convert.ToDouble(ekran.Text);
                operandPressed = false;
                ekran.Text = data;
                return;
            }
            if (operands.Contains(data))
            {
                switch (action)
                {
                    case "+": equal += f; break;
                    case "-": equal -= f; break;
                    case "×": equal *= Convert.ToDouble(ekran.Text); break;
                    case "÷": equal /= Convert.ToDouble(ekran.Text); break;
                    case "x²": equal *= Convert.ToDouble(ekran.Text); break;
                    //wszystkie powyżej działają
                    case "xª": equal *= Convert.ToDouble(ekran.Text); break;
                    case "%": equal *= (Convert.ToDouble(ekran.Text) * 0.01); break;
                    //"%" w trakcie robienia
                    case "(": equal = Convert.ToDouble(ekran.Text); break;
                    case ")": equal = Convert.ToDouble(ekran.Text); break;
                    case ",": equal = Convert.ToDouble(ekran.Text); break;
                    case "mod": equal = Convert.ToDouble(ekran.Text); break;
                    case "exp": equal = Convert.ToDouble(ekran.Text); break;
                    case "✓": equal = Math.Sqrt(Convert.ToDouble(ekran.Text)); break;
                    //"," działa
                    //"✓" działa
                    //Go_Back działa
                    //ClearButton_Click działa
                    default: equal = Convert.ToDouble(ekran.Text); break;
                }
                if (data != "=") action = data;

                ekran.Text = equal.ToString(); 
                
                operandPressed = true;
            }
            else
            {
                ekran.Text += data.ToString();
            }
        }

        private void OK_Button_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.C)
            {
                ((Button)sender).Content = "WITAJ";
            }
            if (e.Key == Key.D)
            {
                ((Button)sender).Content = "ŻEGNAJ";
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            ekran.Text = "";
            action = "";
            operandPressed = false;
            equal = .0;
            f = 0;
        }

        private void etykieta1_KeyDown(object sender, KeyEventArgs e)
        {
            //if (ekran.Text)
        }

        private void Go_Back(object sender, RoutedEventArgs e)
        {
            string d = ekran.Text.ToString();
            if (ekran.Text != "")
            {
                string Return = d.Substring(0, d.Length - 1);
                ekran.Text = Return;
            }
        }

        private void E_Click(object sender, RoutedEventArgs e)
        {
            double _E = Math.E;
            string d = ekran.Text.ToString();
            char k = d[d.Length - 1];
            if (k == '+' || k == '-' || k == '*' || k == '/')
            {
                d += _E.ToString();
                ekran.Text = d;
            }
            else
            {
                ekran.Text = _E.ToString();
            }
        }

        private void PI_Click(object sender, RoutedEventArgs e)
        {
            double PI = Math.PI;
            string d = ekran.Text.ToString();
            char k = d[d.Length - 1];
            if (k == '+' || k == '-' || k == '*' || k == '/')
            {
                d += PI.ToString();
                ekran.Text = d;
            }
            else
            {
                ekran.Text = PI.ToString();
            }
        }
    }
}