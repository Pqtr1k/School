﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kalkulator
{
    internal class Calc
    {
        public double dodawanie()
        {
            return 0;
        }
    }

   
}
